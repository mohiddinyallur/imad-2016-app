from flask import Flask,render_template,flash,request,url_for,redirect,session
from dbConnect import connection
from MySQLdb import escape_string as thwart
import gc

app=Flask(__name__)
app.secret_key = "super secret key"

@app.route('/')
def home():
	if 'logged_in' in session:
		return redirect("/booking/")
	else:
		flash("Login required")
		return render_template("index.html")

@app.route('/signup/',methods=["GET","POST"])		
def signup():
	error = None

	try:

		c,conn = connection()

		if request.method == "POST":
			name = request.form['name']
			email = request.form['email']
			password = request.form['password']			

			x = c.execute("INSERT into users (name,email,password) VALUES (%s,%s,%s)",(thwart(name),thwart(email),thwart(password)))

			if x == True:
				flash("Successfully registered!")
				conn.commit()			
				conn.close()
				gc.collect()
				session['logged_in'] = True
				return redirect("/booking/")
			else:
				flash("Error signing up!")

	except Exception as e:
		flash(e)

	return render_template('signup.html')

@app.route('/Login/',methods = ['GET','POST'])
def Login():
	error = None
	if 'logged_in' in session:
		return redirect("/booking/")

	else:

		try:
			flag = 0

			if request.method == "POST":
				attempted_email = request.form['email']
				attempted_password = request.form['password']

				c,conn = connection()

				data = c.execute("SELECT * from users WHERE email = (%s) and password = (%s)",(thwart(attempted_email),thwart(attempted_password)))
				
				data = c.fetchall()
				for i in data:
					if attempted_email == i[2] and attempted_password == i[3]:
						flag = 1
						id = i[0]

				if flag == 1:
					session['logged_in'] = True
					session['user_id'] = id
					return redirect("/booking/")
				else:
					flash("Invalid credentials! Try again!")	
			
			else:
				return render_template('Login.html',error=error)

		except Exception as e:
			flash(e)


	return render_template('Login.html')

@app.route('/booking/',methods=["GET","POST"])
def booking():
	error = None
	parameters = None
	title = ""
	table = ""
	try:
		c,conn = connection()
		if request.method == "POST":
			source = request.form.get('source')
			destination = request.form.get('destination')
			date = request.form['date']

			if source == destination:
				flash("Ridiculous query user! Your source and destinations must be different!")

			else:
				c.execute("SELECT * FROM schedule WHERE source = (%s) and destination = (%s) and depart = (%s)",(source,destination,date))
				data = c.fetchall()

				if data:
					title = ['The ','available',' schedule ','is ','below']
					table = ['Trip Id','Airline Company','Source','Destination','Depart','Arrival','EC','BC','FC','BaseFare']

					for i in data:
						c.execute("select * from airlineCompany where companyId = %s",str(i[1]))
						row = c.fetchone()
						tripId = i[0]
						company = row[1]
						source = i[3]
						destination = i[4]
						Ddate = i[5]
						Adate = i[6]
						e = i[7]
						b = i[8]
						f = i[9]
						fare = i[10]

						parameters = [tripId,company,source,destination,Ddate,Adate,e,b,f,fare]

						flash(parameters)

				else:
					flash(['No service for the queried destinations!'])

		
	except Exception as e:
		flash(e)

	return render_template('booking.html',title=title,table=table,parameters=parameters)


@app.route('/ticket/')	
def ticket():
	return render_template('ticket.html')


@app.route('/schedule/',methods=["GET","POST"])	
def schedule():
	error = None

	try:

		c,conn = connection()

		if request.method == "POST":
			tripId = request.form['tripid']
			count = int(request.form['count'])
			travelClass = request.form.get('class')
			acno = request.form['acno']
			acnop = request.form['acnop']

			'''flash(tripId)
			flash(count)
			flash(travelClass)
			flash(acno)
			flash(acnop)'''

			uid = session['user_id']
			c.execute("SELECT name FROM users where id = %s",str(uid))
			z = c.fetchone()
			name = z[0]

			c.execute("select * from schedule where tripId = %s",thwart(tripId))
			data = c.fetchone()

			if data:
				if travelClass == 'e':
					if count<= data[7]:
						#flash("Tickets available!")
						#flash(uid)
						Class = "Economy"

						
						#flash(name[0])
						

						if count == 1:
							seat = str(data[7])
						else:
							seat = str(data[7]-count+1) + " to " + str(data[7])

						#flash(count)
						#flash("Till here it's fine")
						#flash("tid" + tripId)

						x = c.execute('INSERT INTO bookedTickets (userId,tripId,count,class,seatNumbers) VALUES (%s,%s,%s,%s,%s)',(uid,tripId,count,Class,seat))
						y = c.execute('UPDATE schedule set economyClass = %s where tripId = %s',((data[7] - count),tripId))
						
						#flash(x)
						#flash(y)

						if x == True:
							
							conn.commit()	

							c.execute('select * from bookedTickets where userId = %s and tripId = %s order by ticketId desc',(str(uid),tripId))
							z = c.fetchone()
							tid = z[0]
							conn.close()
							gc.collect()
							
							#flash(data[5])
							#flash(data[6])
							#flash(data[10]*count)

							credentials = ["Booking successful",tid,name,tripId,data[3],data[4],data[5],data[6],seat,data[10]*count]
							flash(credentials)
							
							return redirect(url_for('ticket'))
							#return render_template('ticket.html')
						else:
							flash("Error signing up!")
					else:
						flash(data[7])
						flash("No seats available")
						#return redirect(url_for(booking))


				elif travelClass == 'b':
						if count<= data[8]:
							#flash("Tickets available!")
							#flash(uid)
							Class = "Business"

							
							#flash(name[0])
							

							if count == 1:
								seat = str(data[8])
							else:
								seat = str(data[8]-count+1) + " to " + str(data[8])

							#flash(count)
							#flash("Till here it's fine")
							#flash("tid" + tripId)

							x = c.execute('INSERT INTO bookedTickets (userId,tripId,count,class,seatNumbers) VALUES (%s,%s,%s,%s,%s)',(uid,thwart(tripId),count,Class,seat))
							y = c.execute('UPDATE schedule set businessClass = %s where tripId = %s',((data[8] - count),tripId))
							
							#flash(x)
							#flash(y)

							if x == True:
								
								conn.commit()	

								c.execute('select * from bookedTickets where userId = %s and tripId = %s order by ticketId desc',(str(uid),thwart(tripId)))
								z = c.fetchone()
								tid = z[0]
								conn.close()
								gc.collect()
								
								#flash(data[5])
								#flash(data[6])
								#flash(data[10]*count)

								credentials = ["Booking successful",tid,name,tripId,data[3],data[4],data[5],data[6],seat,data[10]*count*2]
								flash(credentials)
								
								return redirect(url_for('ticket'))
								#return render_template('ticket.html')
							else:
								flash("Error signing up!")
						else:
							flash(data[8])
							flash("No seats available")
							#return redirect(url_for(booking))

				else :
						if count<= data[9]:
							#flash("Tickets available!")
							#flash(uid)
							Class = "Business"

							
							#flash(name[0])
							

							if count == 1:
								seat = str(data[9])
							else:
								seat = str(data[9]-count+1) + " to " + str(data[9])

							#flash(count)
							#flash("Till here it's fine")
							#flash("tid" + tripId)

							x = c.execute('INSERT INTO bookedTickets (userId,tripId,count,class,seatNumbers) VALUES (%s,%s,%s,%s,%s)',(uid,thwart(tripId),count,Class,seat))
							y = c.execute('UPDATE schedule set businessClass = %s where tripId = %s',((data[9] - count),tripId))
							
							#flash(x)
							#flash(y)

							if x == True:
								
								conn.commit()	

								c.execute('select * from bookedTickets where userId = %s and tripId = %s order by ticketId desc',(str(uid),thwart(tripId)))
								z = c.fetchone()
								tid = z[0]
								conn.close()
								gc.collect()
								
								#flash(data[5])
								#flash(data[6])
								#flash(data[10]*count)

								credentials = ["Booking successful",tid,name,tripId,data[3],data[4],data[5],data[6],seat,data[10]*count*3]
								flash(credentials)
								
								return redirect(url_for('ticket'))
								#return render_template('ticket.html')
							else:
								flash("Error signing up!")
						else:
							flash(data[9])
							flash("No seats available")
							#return redirect(url_for(booking))

			else:
				flash("You have chosen a non-existing tripId! Please go back and refer the correct one!")

	except Exception as e:
		return flash(e);



	return render_template('schedule.html')


@app.route('/ticketHistory/')
def ticketHistory():
	return render_template('ticketHistory.html')


@app.route('/logout/')
def logout():
    # remove the username from the session if it's there
    session.pop('logged_in', None)
    return redirect(url_for('home'))

app.debug = True
app.run()
